    <?php 
        $sterren=round($movie['score']/2);
            for($s=0; $s<$sterren; $s++){
            echo(' <i class="fas fa-star"></i>');
            }
     ?>
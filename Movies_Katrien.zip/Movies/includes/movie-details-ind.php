<?php
foreach ($movies as $movie){
        //$review=strip_tags($movie["synopsis"]);
        printf('<a href="movie.php?id=%d" class="movieCard-link">', $movie['id']);
    ?>

          <article class="movieCard">
            <div class="movieCard-image">
              <?php printf('<img src="%s" alt="%s">',$movie['poster'],$movie['title']); ?>
            </div>
            <div class="movieCard-content">
                <h1 class="movieCard-title"><?php echo $movie['title'] ?></h1>
                <p class="movieCard-release"><?php echo $movie['release']->format('d m Y'); ?></p>
                <p class="movieCard-review"><?php echo(substr(strip_tags($movie['synopsis']),0,100)) ; ?></p>
                <p class="movieCard-director"><b>Directed By</b>: <br><?php echo $movie['director'] ?></p>
            </div>
            <div class="movieCard-score"> 
           
            <?php include('./includes/sterren.php') ?>
            </div>  
            <div class="movieCard-reviewCount">
          
                <i class="far fa-comment"></i>   <?php echo count($movie['reviews']); ?>
            </div>
          </article>
</a>
<?php } 
?>
    <?php
        foreach ($movies as $movie_id =>$items){
        //  $review=strip_tags($movie["synopsis"]);
      ?>
        <article class="movieDetail">
          <div class="movieDetail-image">
            <img src="images/ironman.jpg" alt="Iron Man">
          </div>
          <div class="movieDetail-content">
<!--carddetail-->          
            <header class="movieDetail-header">
                <div class="movieDetail-score">
                <?php include('./includes/sterren.php') ?>
                
                </div>  
                <h1 class="movieDetail-title"><?php echo $movie['title'] ?></h1>
                <p class="movieDetail-release"><b>Released on</b>: <?php echo $movie['release']->format('d m Y'); ?></p>
                <p class="movieDetail-director"><b>Directed by</b>: <?php echo $movie['director'] ?></p>
            </header>
<!--synopsis-->
            <div class="movieDetail-synopsis">
              <p><?php echo $movie['synopsis'] ?></p>
            </div>
<!--review-->
            <aside class="movieDetail-reviews">
              <h1 class="movieDetail-reviews-title">Reviews</h1>
              <?php 
              if(count ($movie['reviews'] )>0){
                 foreach($movie['reviews'] as $review){
                  printf('<article class="movieReview">%s </article>',$review);
               } 
              }else{
                  echo ("<p>er zijn geen reviews ter beschikking</p>");
                }
              
              ?>
             </aside>
          </div>
       </article>

<?php } 
?>                
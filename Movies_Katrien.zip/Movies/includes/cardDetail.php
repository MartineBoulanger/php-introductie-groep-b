
<!--carddetail-->          
<header class="movieDetail-header">
                <div class="movieDetail-score">
                <?php include('./includes/sterren.php') ?>
                
                </div>  
                <h1 class="movieDetail-title"><?php echo $movie['title'] ?></h1>
                <p class="movieDetail-release"><b>Released on</b>: <?php echo $movie['release']->format('d m Y'); ?></p>
                <p class="movieDetail-director"><b>Directed by</b>: <?php echo $movie['director'] ?></p>
</header>

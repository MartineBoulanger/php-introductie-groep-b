
<!--synopsis-->
<div class="movieDetail-synopsis">
              <p><?php echo $movie['synopsis'] ?></p>
</div>

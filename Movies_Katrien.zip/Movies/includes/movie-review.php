
<!--review-->
<aside class="movieDetail-reviews">
              <h1 class="movieDetail-reviews-title">Reviews</h1>
              <?php 
              if(count ($movie['reviews'] )>0){
                 foreach($movie['reviews'] as $review){
                  printf('<article class="movieReview">%s </article>',$review);
               } 
              }else{
                  echo ("<p>er zijn geen reviews ter beschikking</p>");
                }
              
              ?>
</aside>

<!-- 

   Opsplitsen in include files
    - moviecard.php
    - footer.php (jaartal via PHP afdrukken)

  Array inlezen en juiste film opzoeken  
    -> $id = $_GET['id'];
    -> Juiste velden afdrukken in de tekst
    -> Reviews overlopen
    -> Gebruik een IF structuur en toon een melding "<p>Er zijn nog geen reviews</p>" als er geen reviews zijn.
        -> bv. iron man 3

  BONUS: Related movies opzoeken uit array en overlopen
    -> hergebruik de MovieCard include file
    -> Toon de volledige Related movies sectie ENKEL als er gerelateerde films zijn
 -->
 <?php 
 include('./includes/movie_array.php');
$id = $_GET['id'];
$movie=$movies[$id];
?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
   <title>Iron Man - Marvel Movies</title>
 </head>
 <body>
 
   <div class="page-content">
     <div class="container">
       <h1><img src="images/marvel-logo.png" alt="Marvel Studios"></h1>
       <p class="text-center"><a href="index.php" class="back-btn">Back to list</a></p>
      
      <!--<article class="movieDetail">
          <div class="movieDetail-image">
            <img src="images/ironman.jpg" alt="Iron Man">
          </div>
          <div class="movieDetail-content">-->
          
           <!-- <header class="movieDetail-header">
                <div class="movieDetail-score">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>  -->
                <?php include('./includes/moviecard.php') ?>
                <!--<h1 class="movieDetail-title">Iron Man</h1>
                <p class="movieDetail-release"><b>Released on</b>: 23 april 2019</p>
                <p class="movieDetail-director"><b>Directed by</b>: Jon Favreau</p>
            </header>-->
            

          <div class="movieDetail-synopsis">
              <p>When history tells the story of the Marvel Cinematic Universe, the tale will always begin with the introduction of Tony Stark (Robert Downey Jr.) in Jon Favreau's Iron Man. An engineering prodigy and genius who follows in his father's footsteps to run the world's biggest weapons manufacturer, Tony is first presented as a careless playboy only interested in making money. That all changes, however, when he is kidnapped by a deadly terrorist organization demanding his technology. With the help of a fellow hostage, Ho Yinsin (Shaun Toub), he uses his ingenuity to design a suit of armor to escape... but it's an experience that winds up haunting him.</p><p>Tony finds himself unable to live with the idea of his inventions harming innocent lives, and upon returning home he not only shuts down weapons manufacturing at his company, but begins to advance and improve the armor he invented. With the backing of his best friend, Air Force Col. James \"Rhodey\" Rhodes (Terrence Howard), and his trusty assistant, Pepper Potts (Gwyneth Paltrow), he successfully roots out the man responsible for his kidnapping -- his business partner Obadiah Stane (Jeff Bridges) -- and changes the world forever when he announces that he is actually a superhero: the Iron Man. Of course, as he would learn from S.H.I.E.L.D. Director Nick Fury (Samuel L. Jackson) in a post-credits scene, this was just his first step into a larger world.</p>
            </div>
            <aside class="movieDetail-reviews">
              <h1 class="movieDetail-reviews-title">Reviews</h1>

              <article class="movieReview">
                Tien jaar geleden lag deze film aan de basis van het huidige Marvel Cinematic Universe. We kunnen dus stellen dat het allemaal de schuld is van Robert Downey Jr. als Tony Stark. Hij moest maar niet zo'n sympathieke klootzak spelen.
              </article>
              <article class="movieReview"> 
                  The amazing yet realistic action is paced by the plot and characters that keep you interested from start to finish. What absolutely blew me away were the phenomenal special effects. I know they built a practical, working armor. What I loved is the use of CGI was used to augment the real life armor and not create something from scratch. Most all CGI constructs feel fake somehow but the stuff in Iron Man didn't seem fake even for an instant. As great as everything looked, what really drives the movie is the emotional resonance and down to earth nature of the plot. Sure the concept is wild but it's all presented so that you really believe it could happen. I doubt anyone will find fault with this movie unless they went in trying to dislike it.
              </article>
            </aside>
          </div>
      <!-- </article>-->

       <section class="relatedMovies">
         <h1 class="relatedMovies-title">Related movies</h1>

         <section class="movies">
         <?php include('./includes/movie-related.php') ?>
            <!--<a href="movie.html?id=2" class="movieCard-link">
              <article class="movieCard">
                <div class="movieCard-image">
                  <img src="images/ironman2.jpg" alt="Iron Man 2">
                </div>
                <div class="movieCard-content">
                  <h1 class="movieCard-title">Iron Man 2</h1>
                  <p class="movieCard-release">23 april 2008</p>
                  <p class="movieCard-review">In August 2014, James Gunn offered Marvel fans a very different flavor of blockbuster with Guardians of the Galaxy -- a sci-fi space opera c...</p>
                  <p class="movieCard-director"><b>Directed By</b>: <br> Jon Favreau</p>
                </div>
                <div class="movieCard-score">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>  
                <div class="movieCard-reviewCount">
                    <i class="far fa-comment"></i> 2
                </div>
              </article>
            </a>-->
    
          
          </section>
       </section>
     </div>
   </div>
 
   <footer class="page-footer">
     <div class="container">
     Marvel Studios - &copy;  <?php include('./includes/main-footer.php') ?>
     </div>
   </footer>
   
 </body>
 </html>
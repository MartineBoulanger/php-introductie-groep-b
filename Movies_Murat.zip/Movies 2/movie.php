<!-- 

   Opsplitsen in include files
    - moviecard.php
    - footer.php (jaartal via PHP afdrukken)

  Array inlezen en juiste film opzoeken  
    -> $id = $_GET['id'];
    -> Juiste velden afdrukken in de tekst
    -> Reviews overlopen
    -> Gebruik een IF structuur en toon een melding "<p>Er zijn nog geen reviews</p>" als er geen reviews zijn.
        -> bv. iron man 3

  BONUS: Related movies opzoeken uit array en overlopen
    -> hergebruik de MovieCard include file
    -> Toon de volledige Related movies sectie ENKEL als er gerelateerde films zijn
 -->
<?php 
include ('./includes/movie_array.php');
$id = $_GET['id'];
$movie = $movies[$id];
?>


 <!DOCTYPE html>
 <html lang="en">
 <head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
   <title><?php echo $movie['title']; ?></title>
 </head>
 <body>
 
   <div class="page-content">
     <div class="container">
       <h1><img src="images/marvel-logo.png" alt="Marvel Studios"></h1>
       <p class="text-center"><a href="index.php" class="back-btn">Back to list</a></p>
      
       <article class="movieDetail">
          <div class="movieDetail-image">
            <img src="<?php echo $movie['poster']; ?>" alt="<?php echo $movie['title']; ?>">
          </div>
          <div class="movieDetail-content">
            <header class="movieDetail-header">
                <div class="movieDetail-score">
                <?php 
                $stars = ceil($movie['score'] / 2); 
                for($i = 0; $i < $stars; $i++) {
                      echo '<i class="fas fa-star"></i>';
                } 
                ?> 
                </div>  
                <h1 class="movieDetail-title"><?php echo $movie['title']; ?></h1>
                <p class="movieDetail-release"><b>Released on</b>: <?php echo $movie['release']->format('d M Y') ?></p>
                <p class="movieDetail-director"><b>Directed by</b>: <?php echo $movie['director']; ?></p>
            </header>

            <div class="movieDetail-synopsis">
            <?php echo $movie['synopsis']; ?>
            </div>
            <aside class="movieDetail-reviews">
              <h1 class="movieDetail-reviews-title">Reviews</h1>
         
            <?php $reviews = $movie['reviews']; ?>
             
             <?php foreach($reviews as $review): ?>
                <article class="movieReview">
                  <?php echo $review ?>
                </article>
             <?php  endforeach; ?>

            </aside>
          </div>
       </article>

       <section class="relatedMovies">
         <h1 class="relatedMovies-title">Related movies</h1>

         <section class="movies">
        
         <?php $related_movies = $movie['related']; ?>
         <?php foreach($related_movies as $movie_id): ?>
          <?php $movie = $movies[$movie_id]; ?>
          <?php include('./includes/moviecard.php'); ?>
          <?php endforeach; ?>

          </section>
       </section>
     </div>
   </div>
 
   <footer class="page-footer">
   <footer class="page-footer">
  <?php include('./includes/footer.php')?>
  </footer>
   </footer>
   
 </body>
 </html>
<a href="movie.php?id=<?php echo $movie['id'] ?>" class="movieCard-link">
          <article class="movieCard">
            <div class="movieCard-image">
              <img src="<?php echo $movie['poster'] ?>" alt="<?php echo $movie['title'] ?>">
            </div>
            <div class="movieCard-content">
              <h1 class="movieCard-title"><?php echo $movie['title'] ?></h1>
              <p class="movieCard-release"><?php echo $movie['release']->format('d m Y') ?></p>
              <p class="movieCard-review">  
                   <?php
                    $string = strip_tags($movie['synopsis']);
                     $string = substr($string, 0, 100);                   
                     echo $string."… ";
                     ?></p>
              <p class="movieCard-director"><b>Directed By</b>: <br> <?php echo $movie['director'] ?></p>
            </div>
            <div class="movieCard-score">
                <!--  -->
                <?php 
                $stars = ceil($movie['score'] / 2); 
                for($i = 0; $i < $stars; $i++) {
                      echo '<i class="fas fa-star"></i>';
                } 
                ?>         
            </div>  
            <div class="movieCard-reviewCount">
                <i class="far fa-comment"></i> <?php echo $movie['id']; ?>
            </div>
          </article>
        </a>       